# Google Docs Clone

A react app built using Quill Text editor and Socket.io.
Socket enables many users to collaboratively edit on a master document together.

---

Used Tech:

1. React
2. NodeJS
3. QuillJS
4. Socket.io
5. MongoDB
6. Express

Deployed 🐱‍🏍: [<u>**Vercel**</u>](https://google-docs-clone-client.vercel.app/)

